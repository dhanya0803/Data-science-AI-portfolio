# Fine-Grained Emotion Classification

This project uses the GoEmotions dataset for multi-label emotion
classification.

Models:
- BERT
- RoBERTa
- DistilBERT
- Qwen2.5-0.5B-Instruct with LoRA

## How to run

1. Open `notebooks/GoEmotions_Model_Comparison.ipynb` in Google Colab.
2. Select a GPU runtime (Runtime -> Change runtime type -> GPU).
3. Install the required packages (first cell of the notebook).
4. Mount Google Drive when prompted -- model checkpoints and results save there automatically.
5. Run the notebook cells in order.

For Demo Day, use `Final_Demo_Local.ipynb` instead -- it loads the trained
checkpoints and runs entirely on local hardware, with no Colab or GPU
required. See `requirements.txt` for its dependencies.

The final Streamlit application is also included in the training notebook
(Part 6),.

## Dataset

GoEmotions dataset (Google Research) -- 58,009 human-annotated Reddit
comments, 27 emotions plus neutral, multi-label. Official split: 43,410
train / 5,426 dev / 5,427 test.

## Main evaluation metric

Macro-F1, with Micro-F1, per-class precision/recall, and confusion
matrices reported as secondary metrics.

## Main research questions

RQ1: Which of BERT, RoBERTa, and DistilBERT gives the best balance of
performance and computational efficiency on GoEmotions?

RQ2: What is the effect of per-class threshold tuning on multi-label
emotion classification performance?

RQ3: Does LoRA fine-tuning improve Qwen2.5-0.5B-Instruct's emotion
classification over its own zero-shot / few-shot prompting baseline?

## Results (test set)

| Model | Macro-F1 | Micro-F1 |
|---|---|---|
| BERT | 0.5272 | 0.6078 |
| RoBERTa | 0.5340 | 0.6021 |
| DistilBERT | 0.5092 | 0.5994 |

Per-class threshold tuning (RQ2) improved Macro-F1 for all three encoders.
The Qwen2.5 LoRA result (RQ3) is reported as a limitation; see `docs/Final_Report_RedBlack_NoID.pdf`.

## Repository layout

- `notebooks/` – training, evaluation and Colab demo notebook
- `Final_Demo_Local.ipynb` – local, GPU-free demo
- `docs/` – final report and presentation
- `models/`, `thresholds/` – place trained checkpoints here (not tracked in git; too large)

## Notes

Model checkpoints are not included. Train them with the notebook, or copy them from your Google Drive `goemotions_project` folder.
Never commit API keys or tokens.
