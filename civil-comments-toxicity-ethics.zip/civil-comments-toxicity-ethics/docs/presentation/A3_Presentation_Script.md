# Oral Presentation Script — ECS8059 Assignment 3
**Target: 6 minutes. Point at the poster as you speak — don't read it aloud.**

---

## 1. Problem (0:00–0:45)

*[Stand by the header/Section 01]*

"My project looks at Civil Comments — a dataset used to train AI systems that automatically detect toxic comments for content moderation, at scale, without a human reviewing every flag.

The problem is that these classifiers can treat a comment as toxic simply because it *mentions* an identity group — someone's race, religion, sexual orientation — even when the comment itself is completely harmless. That's the core ethical issue this whole poster is built around."

---

## 2. Evidence (0:45–2:15)

*[Move to Section 03 — point to the scatter plot]*

"Here's what I found. Each dot is one of ten thousand real comments. Above this dashed line, the classifier calls it toxic. Comments that don't mention identity — mostly clustered down here, 4.1% cross the line. Comments that do mention identity — 33.9% cross it. That's roughly eight times higher, and it's statistically robust — p less than 0.0001.

*[Point to confusion matrix]*

I've also put this in a format anyone who's worked with a classifier will recognise — a confusion matrix. The quadrant that matters is here: false flags. Non-toxic, identity-mentioning comments land in this box eight times more often than they should.

*[Point to feature-importance chart]*

And this chart shows why: of the six things this dataset labels, insult drives most toxicity scores overall — that's expected. But identity_attack is the third strongest predictor, at 0.44. It's not the only signal, but it's a real one."

---

## 3. Research (2:15–3:15)

*[Move to the Finding card in column 2]*

"So is this the model's fault? Partly — but the literature I reviewed for Assignment 2 shows the bias starts earlier than that. Annotators' own beliefs and identities measurably shift how they label toxic language — that's not my finding, that's established research. Which means some of this eight-times gap may come from who was doing the labelling, not just what was written."

---

## 4. Governance (3:15–4:45)

*[Move to Section 04]*

"Three regulatory frameworks apply to a system like this. The EU Digital Services Act requires transparency reports and gives researchers a route to request platform data. The UK Online Safety Act gives Ofcom power to enforce risk-management duties over moderation algorithms. And the EU AI Act adds data-governance and oversight requirements — though a classifier like this likely falls outside its high-risk category, so the strongest obligations probably don't apply.

*[Point to the dark gap box]*

Here's the problem: all three require transparency in general. None of them requires a platform to break its error rate down by identity subgroup. So a platform could fully comply with all three laws and still be running exactly the biased system I just showed you."

---

## 5. Limitations (4:45–5:30)

*[Move to Section 05]*

"I want to be upfront about what this doesn't prove. This is a 10,000-comment sample, not the full 1.8 million. The public dataset has no identity labels, so I can't say which specific groups are most affected. What I've shown is an association, not proof that mentioning an identity *causes* the toxic label. And bias findings from other datasets, mostly Twitter, may not fully generalise to this news-comment context."

---

## 6. Position (5:30–6:15)

*[Return to the amber band, point directly at it]*

"So here's where that leaves me. Given an eight-times disparity, an annotation process we know can carry bias, and three governance frameworks that all stop short of requiring the one thing that would actually surface this — my position is:

**Deploy only with human oversight, subgroup fairness auditing, and mandatory dataset documentation.**

Not 'don't use this.' Not 'it's fine as is.' Deploy it — but only once you can actually see, and report, how it treats different groups differently. Thank you."

*[Stop talking. Let the room ask questions.]*

---

## Quick-fire Q&A bank

| If asked... | Say... |
|---|---|
| Why this graph? | "Shows the actual classifier threshold, not just a percentage." |
| Why the confusion matrix? | "Names the harm precisely — false flags, not vague 'bias'." |
| Why identity_attack if insult scores higher? | "Insult drives toxicity generally; identity_attack drives the *disparity* between groups." |
| Most important thing on the poster? | "The position band — everything else supports it." |
| Why three frameworks, not one? | "Each regulates a different layer — platform, service, AI system. Same gap shows up in all three." |
| What did you leave out? | "Full 1.8M-comment analysis, per-subtype breakdowns — I kept only the 2–3 strongest findings." |
| Why 'associated with' not 'causes'? | "Chi-squared shows correlation. I didn't run a causal test." |

**Reminders:** Don't apologise for limitations — state them flatly, they're a strength. Don't read text off the poster verbatim except the position line. Breathe between sections.
