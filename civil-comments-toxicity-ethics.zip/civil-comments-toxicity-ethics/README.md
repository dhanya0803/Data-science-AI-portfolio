# The Classifier's Blind Spot: Identity Mentions and Toxicity Labels in Civil Comments

A three-part study for **ECS8059 AI Ethics (Queen's University Belfast)** on how automated toxicity detection can treat *mentions* of identity as evidence of toxicity.

| Part | Output | Location |
|---|---|---|
| A1 | Data analysis (code + figures) | `src/`, `notebooks/`, `figures/` |
| A2 | IEEE-format research paper | `docs/paper/` |
| A3 | A0 poster + oral presentation | `docs/poster/`, `docs/presentation/` |

## Headline findings (10,000-comment random sample, seed 42)

- Binary label: `toxicity >= 0.5`; 7.67% of the sample is toxic.
- Comments with any `identity_attack` signal were labelled toxic **33.9%** of the time versus **4.1%** without one, about **8.3x** higher.
- Chi-squared = 1320.28, p < 0.0001; point-biserial r = 0.331.
- Governance gap: the EU Digital Services Act, UK Online Safety Act and EU AI Act all require transparency, but none requires error rates to be reported by identity subgroup.
- **Position:** deploy only with human oversight, subgroup fairness auditing and mandatory dataset documentation.

These show an *association* in one sample, not that identity mentions cause the toxic label. The public release has no per-identity columns or annotator metadata.

## Reproduce

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python src/download_sample.py --n 10000 --seed 42   # writes data/civil_comments_real_sample.csv
python src/analysis.py                              # prints statistics, writes figures/
jupyter notebook notebooks/A1_analysis.ipynb        # same analysis, step by step
```

`download_sample.py` pulls the Hugging Face parquet export of [`google/civil_comments`](https://huggingface.co/datasets/google/civil_comments) (1,804,874 comments). Because the sampling route differs from the original coursework run, numbers may differ slightly from those quoted above.

## Repository layout

```
src/            download_sample.py, analysis.py, make_notebook.py
notebooks/      A1_analysis.ipynb
data/           (empty; CSV is downloaded, not committed)
figures/        generated PNGs (fig1-fig6)
docs/           paper, poster, presentation materials
```

## Limitations

10,000-comment sample; toxicity-only release (no identity or annotator columns); Mitigation 3 (a per-identity BPSN/BNSP AUC audit on the Jigsaw identity-annotated subset) is described in the notebook but not implemented.

## Data and ethics

The dataset is released by Jigsaw/Conversation AI under CC0; it contains offensive text. No raw comments are stored in this repo.

## References

Borkan et al. (2019) *Nuanced Metrics for Measuring Unintended Bias*; Dixon et al. (2018) *Measuring and Mitigating Unintended Bias in Text Classification*; Sap et al. (2019) *The Risk of Racial Bias in Hate Speech Detection*. Full lists are in `docs/`.

## Licence

Code: MIT. Coursework documents in `docs/` are shared for portfolio purposes; please do not reuse them for assessed work.
