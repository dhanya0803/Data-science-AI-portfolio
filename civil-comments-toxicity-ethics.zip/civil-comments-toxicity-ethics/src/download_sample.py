"""Download a reproducible random sample of Civil Comments.

Uses the Hugging Face dataset-viewer parquet export (the route that worked
when the Kaggle download and datasets.load_dataset() both failed).

Usage:
    python src/download_sample.py --n 10000 --seed 42 --out data/civil_comments_real_sample.csv

Note: the parquet files are large (the train split is ~1.8M comments). Rows are
read one shard at a time, so memory use stays modest. Because the sample is
drawn from the shards that are downloaded, the exact 10,000 rows of the
original coursework run may differ slightly; headline results should be close
but are not guaranteed to match to the decimal place.
"""
import argparse
import io

import pandas as pd
import requests

API = "https://datasets-server.huggingface.co/parquet"
DATASET = "google/civil_comments"
COLS = ["text", "toxicity", "severe_toxicity", "obscene", "threat",
        "insult", "identity_attack", "sexual_explicit"]


def list_train_shards():
    r = requests.get(API, params={"dataset": DATASET}, timeout=60)
    r.raise_for_status()
    files = [f for f in r.json()["parquet_files"] if f["split"] == "train"]
    if not files:
        raise RuntimeError("No train parquet shards returned by the API")
    return files


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=10_000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="data/civil_comments_real_sample.csv")
    a = ap.parse_args()

    shards = list_train_shards()
    per_shard = -(-a.n // len(shards))  # ceil
    parts = []
    for i, f in enumerate(shards):
        print(f"[{i + 1}/{len(shards)}] {f['filename']}")
        raw = requests.get(f["url"], timeout=600).content
        d = pd.read_parquet(io.BytesIO(raw), columns=COLS)
        parts.append(d.sample(n=min(per_shard, len(d)), random_state=a.seed))
    df = (pd.concat(parts, ignore_index=True)
            .sample(n=a.n, random_state=a.seed)
            .reset_index(drop=True))
    df.to_csv(a.out, index=False)
    print(f"Saved {len(df):,} rows -> {a.out}")


if __name__ == "__main__":
    main()
