"""A1 analysis: identity-attack signal vs toxicity in a Civil Comments sample.

Run:  python src/analysis.py --data data/civil_comments_real_sample.csv --out figures
Reproduces the statistics and figures 1-6 from the A1 notebook.
"""
import argparse
import os
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy.stats import chi2_contingency, pointbiserialr

warnings.filterwarnings("ignore")
SUBTYPES = ["severe_toxicity", "obscene", "threat", "insult",
            "identity_attack", "sexual_explicit"]
BLUE, RED = "#4C9BE8", "#E8604C"


def style():
    plt.rcParams.update({"figure.figsize": (10, 5), "font.size": 12})
    sns.set_theme(style="whitegrid")


def load(path):
    df = pd.read_csv(path)
    df["label"] = (df["toxicity"] >= 0.5).astype(int)  # binary label
    return df


def fig1(df, out):
    fig, ax = plt.subplots(1, 2, figsize=(13, 5))
    c = df["label"].value_counts().sort_index()
    ax[0].bar(["Non-toxic", "Toxic"], c.values, color=[BLUE, RED], edgecolor="black")
    ax[0].set_title("Binary label distribution (toxicity >= 0.5)")
    ax[0].set_ylabel("Comments")
    ax[1].hist(df["toxicity"], bins=40, color=BLUE, edgecolor="black")
    ax[1].set_yscale("log")
    ax[1].axvline(0.5, color="red", ls="--", label="Threshold 0.5")
    ax[1].set_title("Toxicity score distribution (log scale)")
    ax[1].set_xlabel("Toxicity score")
    ax[1].legend()
    plt.tight_layout()
    plt.savefig(f"{out}/fig1_label_distribution.png", dpi=150, bbox_inches="tight")
    plt.close()


def fig2(df, out):
    gt0 = [(df[c] > 0).sum() for c in SUBTYPES]
    ge5 = [(df[c] >= 0.5).sum() for c in SUBTYPES]
    x = np.arange(len(SUBTYPES)); w = 0.35
    fig, ax = plt.subplots()
    pal = sns.color_palette("Set2", 2)
    ax.bar(x - w / 2, gt0, w, label="score > 0", color=pal[0], edgecolor="black")
    ax.bar(x + w / 2, ge5, w, label="score >= 0.5", color=pal[1], edgecolor="black")
    ax.set_xticks(x); ax.set_xticklabels(SUBTYPES, rotation=30, ha="right")
    ax.set_ylabel("Comments"); ax.set_title("Toxicity subtype prevalence"); ax.legend()
    plt.tight_layout()
    plt.savefig(f"{out}/fig2_subtype_distribution.png", dpi=150, bbox_inches="tight")
    plt.close()


def fig3(df, out):
    corr = (df[["toxicity"] + SUBTYPES].corr()["toxicity"]
            .drop("toxicity").sort_values())
    fig, ax = plt.subplots()
    ax.barh(corr.index, corr.values, color=sns.color_palette("viridis", len(corr)),
            edgecolor="black")
    ax.set_xlabel("Pearson r with toxicity")
    ax.set_title("Correlation of each subtype with overall toxicity")
    plt.tight_layout()
    plt.savefig(f"{out}/fig3_subtype_correlation.png", dpi=150, bbox_inches="tight")
    plt.close()
    return corr.sort_values(ascending=False)


def split_ia(df):
    return df[df["identity_attack"] > 0], df[df["identity_attack"] == 0]


def issue1(df, out):
    ia, no_ia = split_ia(df)
    r1, r0 = ia["label"].mean() * 100, no_ia["label"].mean() * 100
    print(f"Identity-attack signal  (n={len(ia)}): {r1:.1f}% toxic")
    print(f"No identity-attack      (n={len(no_ia)}): {r0:.1f}% toxic")
    print(f"Ratio: {r1 / r0:.1f}x")
    table = pd.crosstab(df["identity_attack"] > 0, df["label"])
    chi2, p, dof, _ = chi2_contingency(table)
    r, _ = pointbiserialr(df["label"], df["identity_attack"])
    print(f"Contingency table:\n{table}")
    print(f"Chi-squared = {chi2:.2f}, dof = {dof}, p = {p:.3g}")
    print(f"Point-biserial r = {r:.3f}")

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.bar(["Identity-attack\nsignal", "No identity-\nattack signal"], [r1, r0],
           color=[RED, BLUE], edgecolor="black")
    ax.axhline(df["label"].mean() * 100, color="black", ls="--", label="Overall rate")
    ax.set_ylabel("Toxicity rate (%)")
    ax.set_title("Toxicity rate by identity-attack signal")
    ax.legend(); plt.tight_layout()
    plt.savefig(f"{out}/fig4_identity_attack_toxicity_gap.png", dpi=150, bbox_inches="tight")
    plt.close()


def mitigation1(df, out):
    ia, no_ia = split_ia(df)
    print("=== BEFORE ===")
    print(f"Identity-attack subgroup (n={len(ia)}): {ia['label'].mean()*100:.1f}% toxic")
    print(f"Rest (n={len(no_ia)}): {no_ia['label'].mean()*100:.1f}% toxic")
    tox, non = ia[ia["label"] == 1], ia[ia["label"] == 0]
    k = min(len(tox), len(non))
    bal = pd.concat([tox.sample(n=k, random_state=42), non.sample(n=k, random_state=42)])
    print("=== AFTER (subgroup rebalanced 50/50) ===")
    print(f"Identity-attack subgroup (n={len(bal)}): {bal['label'].mean()*100:.1f}% toxic")

    labels = ["Identity-attack\nsubgroup", "Rest of\ndataset"]
    before = [ia["label"].mean() * 100, no_ia["label"].mean() * 100]
    after = [bal["label"].mean() * 100, no_ia["label"].mean() * 100]
    x = np.arange(2); w = 0.35
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.bar(x - w / 2, before, w, label="Before mitigation", color=RED, edgecolor="black")
    ax.bar(x + w / 2, after, w, label="After mitigation", color=BLUE, edgecolor="black")
    ax.set_xticks(x); ax.set_xticklabels(labels)
    ax.set_ylabel("Toxicity Rate (%)"); ax.set_ylim(0, 60)
    ax.set_title("Mitigation 1: Rebalancing Within the Identity-Attack Subgroup",
                 fontweight="bold", fontsize=11)
    ax.legend(); plt.tight_layout()
    plt.savefig(f"{out}/fig5_mitigation1_before_after.png", dpi=150, bbox_inches="tight")
    plt.close()


def mitigation2(df, out):
    rows = []
    for c in SUBTYPES:
        if c == "identity_attack":
            continue
        rows.append({
            "Subtype": c,
            "With identity-attack signal (%)": round((df[df["identity_attack"] > 0][c] > 0).mean() * 100, 1),
            "Without identity-attack signal (%)": round((df[df["identity_attack"] == 0][c] > 0).mean() * 100, 1),
        })
    audit = pd.DataFrame(rows)
    print(audit.to_string(index=False))
    x = np.arange(len(audit)); w = 0.35
    fig, ax = plt.subplots()
    ax.bar(x - w / 2, audit.iloc[:, 1], w, label="Has identity-attack signal", color=RED, edgecolor="black")
    ax.bar(x + w / 2, audit.iloc[:, 2], w, label="No identity-attack signal", color=BLUE, edgecolor="black")
    ax.set_xticks(x); ax.set_xticklabels(audit["Subtype"], rotation=30, ha="right")
    ax.set_ylabel("% of Comments With Non-Zero Score")
    ax.set_title("Mitigation 2: Co-occurrence of Other Subtypes With Identity-Attack Signal")
    ax.legend(); plt.tight_layout()
    plt.savefig(f"{out}/fig6_mitigation2_subtype_audit.png", dpi=150, bbox_inches="tight")
    plt.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/civil_comments_real_sample.csv")
    ap.add_argument("--out", default="figures")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    style()
    df = load(a.data)
    print(f"Shape: {df.shape}; toxic rate {df['label'].mean()*100:.2f}%; "
          f"duplicate texts: {df['text'].duplicated().sum()}")
    fig1(df, a.out); fig2(df, a.out)
    print("Correlation with toxicity:\n", fig3(df, a.out).round(3))
    issue1(df, a.out); mitigation1(df, a.out); mitigation2(df, a.out)
    print(f"Figures written to {a.out}/")


if __name__ == "__main__":
    main()
