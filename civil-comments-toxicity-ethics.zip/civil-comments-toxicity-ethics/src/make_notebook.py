"""Builds notebooks/A1_analysis.ipynb (thin wrapper over src/analysis.py)."""
import nbformat as nbf
nb = nbf.v4.new_notebook()
md, code = nbf.v4.new_markdown_cell, nbf.v4.new_code_cell
nb.cells = [
 md("# Civil Comments: identity-attack signal and toxicity labels\nECS8059 AI Ethics, Assignment 1 (code re-organised for GitHub).\n\nRun `python src/download_sample.py` first to create the CSV."),
 code("import sys; sys.path.insert(0, '../src')\nimport matplotlib.pyplot as plt\nimport analysis as A\nA.style()\ndf = A.load('../data/civil_comments_real_sample.csv')\ndf.shape"),
 md("## A. Data overview"),
 code("df['toxicity'].describe()"),
 code("print(df.isna().sum()); print('duplicate texts:', df['text'].duplicated().sum())"),
 code("import os; os.makedirs('../figures', exist_ok=True)\nA.fig1(df, '../figures')"),
 code("A.fig2(df, '../figures'); A.fig3(df, '../figures')"),
 md("## B. Issue 1: identity-attack gap (chi-squared, point-biserial)"),
 code("A.issue1(df, '../figures')"),
 md("## C. Mitigation 1: rebalance the identity-attack subgroup"),
 code("A.mitigation1(df, '../figures')"),
 md("## D. Mitigation 2: subtype co-occurrence audit (proxy only)"),
 code("A.mitigation2(df, '../figures')"),
 md("## E. Mitigation 3 (not executed)\nA genuine subgroup audit needs the identity-annotated subset (~450k comments, 24 identity columns) of *Jigsaw Unintended Bias in Toxicity Classification* and the Subgroup / BPSN / BNSP AUC metrics (Borkan et al., 2019). That data was not accessible during the coursework, so this step is described, not implemented."),
]
nbf.write(nb, "notebooks/A1_analysis.ipynb")
